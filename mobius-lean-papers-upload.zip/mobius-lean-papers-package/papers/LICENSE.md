# License for the two PDF manuscripts in this directory

Copyright © 2026 Xuecuibao Xu. All rights reserved except for the permissions expressly granted below.

The following two PDF manuscripts in this directory only are licensed under the **Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International** license (CC BY-NC-ND 4.0):

- `a-new-upper-bound-mobius-exponential-sums-x15-16.pdf`
- `improved-upper-bound-mobius-exponential-sums-liu-zero-free-region.pdf`

Official license terms: https://creativecommons.org/licenses/by-nc-nd/4.0/

Under the license, you may share the original, unmodified manuscripts in any medium or format, provided you give appropriate attribution, link to the license, and comply with its terms. You may not use the manuscripts for commercial purposes or distribute adapted versions under this license.

This notice does not grant rights to any other material in the repository. The author retains all rights not expressly granted by the license. Please confirm that you hold the necessary rights to apply this license before publishing; this notice is not legal advice.
