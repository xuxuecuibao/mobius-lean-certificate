# Papers on Exponential Sums Formed with the Möbius Function

**Author:** Xuecuibao Xu  
**Affiliation stated in the manuscripts:** School of Mathematics, Shandong University, Jinan, China  
**Date on both manuscripts:** October 10, 2026

This directory contains two PDF manuscripts:

1. **A New Upper Bound for Exponential Sums Formed with the Möbius Function: \(x^{15/16+\varepsilon}\)**
   - File: [`a-new-upper-bound-mobius-exponential-sums-x15-16.pdf`](a-new-upper-bound-mobius-exponential-sums-x15-16.pdf)
   - The manuscript derives a conditional upper bound using the Baker–Harman estimate and the zero-free half-plane stated in the paper.

2. **Improved Upper Bound for Exponential Sums Formed with the Möbius Function: \(x^{(1580-\sqrt{921})/1653+\varepsilon}\)**
   - File: [`improved-upper-bound-mobius-exponential-sums-liu-zero-free-region.pdf`](improved-upper-bound-mobius-exponential-sums-liu-zero-free-region.pdf)
   - The manuscript substitutes the improved zero-free half-plane attributed to Baiying Liu into the Baker–Harman estimate.

## Copyright and license

Copyright © 2026 Xuecuibao Xu. The license in [`LICENSE.md`](LICENSE.md) applies **only to the two PDF manuscripts named above in this directory**. It does not apply to unrelated files elsewhere in the repository.

These PDFs are offered under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International license (CC BY-NC-ND 4.0). See the license notice and official terms in [`LICENSE.md`](LICENSE.md).
